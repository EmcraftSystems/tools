	.abicalls
	.word	foo
