#source: fdpic-plt.s
#as: --isa=sh2a -little --fdpic
#ld: -EL -mshlelf_fd -shared
#objdump: -dsR -j.plt -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-sh-fdpic

Contents of section \.plt:
 0214 f000f0ff ce010470 2b41ce0c 00000000[ \t]+.*
 0224 c2602b40 c1530900 f000f8ff ce010470[ \t]+.*
 0234 2b41ce0c 0c000000 c2602b40 c1530900[ \t]+.*
Contents of section \.text:
 0244 00d001d1 ccffffff e0ffffff[ \t]+.*
Contents of section \.got:
 102c8 24020000 00000000 3c020000 00000000[ \t]+.*
 102d8 00000000 00000000 00000000[ \t]+.*

Disassembly of section \.plt:

00000214 <foo@plt>:
 214:[ \t]+f0 00 f0 ff[ \t]+movi20[ \t]+#-16,r0
 218:[ \t]+ce 01[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 21a:[ \t]+04 70[ \t]+add[ \t]+#4,r0
 21c:[ \t]+2b 41[ \t]+jmp[ \t]+@r1
 21e:[ \t]+ce 0c[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 220:[ \t]+00 00 00 00[ \t]+movi20[ \t]+#0,r0
 224:[ \t]+c2 60[ \t]+mov\.l[ \t]+@r12,r0
 226:[ \t]+2b 40[ \t]+jmp[ \t]+@r0
 228:[ \t]+c1 53[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 22a:[ \t]+09 00[ \t]+nop[ \t]+

0000022c <bar@plt>:
 22c:[ \t]+f0 00 f8 ff[ \t]+movi20[ \t]+#-8,r0
 230:[ \t]+ce 01[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 232:[ \t]+04 70[ \t]+add[ \t]+#4,r0
 234:[ \t]+2b 41[ \t]+jmp[ \t]+@r1
 236:[ \t]+ce 0c[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 238:[ \t]+0c 00[ \t]+mov\.b[ \t]+@\(r0,r0\),r0
 23a:[ \t]+00 00 c2 60[ \t]+movi20[ \t]+#24770,r0
 23e:[ \t]+2b 40[ \t]+jmp[ \t]+@r0
 240:[ \t]+c1 53[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 242:[ \t]+09 00[ \t]+nop[ \t]+

Disassembly of section \.text:

00000244 <f>:
 244:[ \t]+00 d0[ \t]+mov\.l[ \t]+248 <f\+0x4>,r0[ \t]+! ffffffcc
 246:[ \t]+01 d1[ \t]+mov\.l[ \t]+24c <f\+0x8>,r1[ \t]+! ffffffe0
 248:[ \t]+cc ff[ \t]+fmov[ \t]+fr12,fr15
 24a:[ \t]+ff ff[ \t]+\.word 0xffff
 24c:[ \t]+e0 ff[ \t]+fadd[ \t]+fr14,fr15
 24e:[ \t]+ff ff[ \t]+\.word 0xffff

Disassembly of section \.got:

000102c8 <\.got>:
[ \t]+102c8:[ \t]+24 02[ \t]+mov\.b[ \t]+r2,@\(r0,r2\)
[ \t]+102c8: R_SH_FUNCDESC_VALUE[ \t]+foo
[ \t]+102ca:[ \t]+00 00 00 00[ \t]+movi20[ \t]+#0,r0
[ \t]+102ce:[ \t]+00 00 3c 02[ \t]+movi20[ \t]+#572,r0
[ \t]+102d0: R_SH_FUNCDESC_VALUE[ \t]+bar
[ \t]+\.\.\.
