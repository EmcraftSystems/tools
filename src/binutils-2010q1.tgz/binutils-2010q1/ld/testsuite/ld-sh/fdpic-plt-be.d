#source: fdpic-plt.s
#as: --isa=sh4a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.plt -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.plt:
 0214 d00201ce 7004412b 0cce0009 fffffff0[ \t]+.*
 0224 00000000 60c2402b 53c10009 d00201ce[ \t]+.*
 0234 7004412b 0cce0009 fffffff8 0000000c[ \t]+.*
 0244 60c2402b 53c10009[ \t]+.*
Contents of section \.text:
 024c d000d101 ffffffc4 ffffffdc[ \t]+.*
Contents of section \.got:
 102d0 00000228 00000000 00000244 00000000[ \t]+.*
 102e0 00000000 00000000 00000000[ \t]+.*

Disassembly of section \.plt:

00000214 <foo@plt>:
 214:[ \t]+d0 02[ \t]+mov\.l[ \t]+220 <foo@plt\+0xc>,r0[ \t]+! fffffff0
 216:[ \t]+01 ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 218:[ \t]+70 04[ \t]+add[ \t]+#4,r0
 21a:[ \t]+41 2b[ \t]+jmp[ \t]+@r1
 21c:[ \t]+0c ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 21e:[ \t]+00 09[ \t]+nop[ \t]+
 220:[ \t]+ff ff[ \t]+\.word 0xffff
 222:[ \t]+ff f0[ \t]+fadd[ \t]+fr15,fr15
 224:[ \t]+00 00[ \t]+\.word 0x0000
 226:[ \t]+00 00[ \t]+\.word 0x0000
 228:[ \t]+60 c2[ \t]+mov\.l[ \t]+@r12,r0
 22a:[ \t]+40 2b[ \t]+jmp[ \t]+@r0
 22c:[ \t]+53 c1[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 22e:[ \t]+00 09[ \t]+nop[ \t]+

00000230 <bar@plt>:
 230:[ \t]+d0 02[ \t]+mov\.l[ \t]+23c <bar@plt\+0xc>,r0[ \t]+! fffffff8
 232:[ \t]+01 ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 234:[ \t]+70 04[ \t]+add[ \t]+#4,r0
 236:[ \t]+41 2b[ \t]+jmp[ \t]+@r1
 238:[ \t]+0c ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 23a:[ \t]+00 09[ \t]+nop[ \t]+
 23c:[ \t]+ff ff[ \t]+\.word 0xffff
 23e:[ \t]+ff f8[ \t]+fmov[ \t]+@r15,fr15
 240:[ \t]+00 00[ \t]+\.word 0x0000
 242:[ \t]+00 0c[ \t]+mov\.b[ \t]+@\(r0,r0\),r0
 244:[ \t]+60 c2[ \t]+mov\.l[ \t]+@r12,r0
 246:[ \t]+40 2b[ \t]+jmp[ \t]+@r0
 248:[ \t]+53 c1[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 24a:[ \t]+00 09[ \t]+nop[ \t]+

Disassembly of section \.text:

0000024c <f>:
 24c:[ \t]+d0 00[ \t]+mov\.l[ \t]+250 <f\+0x4>,r0[ \t]+! ffffffc4
 24e:[ \t]+d1 01[ \t]+mov\.l[ \t]+254 <f\+0x8>,r1[ \t]+! ffffffdc
 250:[ \t]+ff ff[ \t]+\.word 0xffff
 252:[ \t]+ff c4[ \t]+fcmp/eq[ \t]+fr12,fr15
 254:[ \t]+ff ff[ \t]+\.word 0xffff
 256:[ \t]+ff dc[ \t]+fmov[ \t]+fr13,fr15

Disassembly of section \.got:

000102d0 <\.got>:
[ \t]+102d0:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d0: R_SH_FUNCDESC_VALUE[ \t]+foo
[ \t]+102d2:[ \t]+02 28[ \t]+\.word 0x0228
[ \t]+102d4:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d6:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d8:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d8: R_SH_FUNCDESC_VALUE[ \t]+bar
[ \t]+102da:[ \t]+02 44[ \t]+mov\.b[ \t]+r4,@\(r0,r2\)
[ \t]+\.\.\.
