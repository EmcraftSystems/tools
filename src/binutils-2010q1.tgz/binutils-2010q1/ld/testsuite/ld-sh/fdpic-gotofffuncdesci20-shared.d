#source: fdpic-gotofffuncdesci20-shared.s
#as: --isa=sh2a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.text:
 01c4 01f0fff8 31cc0009[ \t]+.*
Contents of section \.got:
 1023c 00000006 00000000 00000000 00000000[ \t]+.*
 1024c 00000000[ \t]+.*

Disassembly of section \.text:

000001c4 <f>:
 1c4:[ \t]+01 f0 ff f8[ \t]+movi20[ \t]+#-8,r1
 1c8:[ \t]+31 cc[ \t]+add[ \t]+r12,r1

000001ca <foo>:
 1ca:[ \t]+00 09[ \t]+nop[ \t]+

Disassembly of section \.got:

0001023c <\.got>:
[ \t]+1023c:[ \t]+00 00 00 06[ \t]+movi20[ \t]+#6,r0
[ \t]+1023c: R_SH_FUNCDESC_VALUE[ \t]+\.text
[ \t]+\.\.\.
