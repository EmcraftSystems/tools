#source: fdpic-funcdesc-shared.s
#as: --isa=sh2a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.text -j.data -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.text:
 01e8 0009[ \t]+.*
Contents of section \.data:
 1025c 00000000[ \t]+.*
Contents of section \.got:
 10260 00000000 00000000 00000000 00000000[ \t]+.*
 10270 00000000[ \t]+.*

Disassembly of section \.text:

000001e8 <foo>:
 1e8:[ \t]+00 09[ \t]+nop[ \t]+

Disassembly of section \.data:

0001025c <bar>:
[ \t]+1025c:[ \t]+00 00 00 00[ \t]+\.\.\.\.
[ \t]+1025c: R_SH_DIR32[ \t]+\.got

Disassembly of section \.got:

00010260 <\.got>:
[ \t]+\.\.\.
[ \t]+10260: R_SH_FUNCDESC_VALUE[ \t]+\.text
