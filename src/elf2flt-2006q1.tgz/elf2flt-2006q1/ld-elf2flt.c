/*
 * Wrapper for the real linker and the elf2flt converter.  This was
 * originally a simple shell script, but that doesn't work on a
 * windows host without cygwin.
 * The proper long term solution is to add FLT as a BFD output format.
 *
 * Converted from ld-elf2flt.in by Nathan Sidwell, nathan@codesourcery.com.
 *
 * This is Free Software, under the GNU General Public License V2 or greater.
 *
 * Copyright (C) 2006, CodeSourcery Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifndef __WIN32
#include <sys/wait.h>
#endif
#include <unistd.h>
#include <errno.h>
#include <libiberty.h>
#include <filenames.h>

#ifndef WIFSIGNALED
#define WIFSIGNALED(S) (((S) & 0xff) != 0 && ((S) & 0xff) != 0x7f)
#endif
#ifndef WTERMSIG
#define WTERMSIG(S) ((S) & 0x7f)
#endif
#ifndef WIFEXITED
#define WIFEXITED(S) (((S) & 0xff) == 0)
#endif
#ifndef WEXITSTATUS
#define WEXITSTATUS(S) (((S) & 0xff00) >> 8)
#endif
#ifndef WCOREDUMP
#define WCOREDUMP(S) ((S) & WCOREFLG)
#endif
#ifndef WCOREFLG
#define WCOREFLG 0200
#endif

/* Structure to hold a list of options */

typedef struct
{
  const char **options;
  size_t num;
  size_t alloc;
} options_t;

/* A simple replacement pattern */
typedef struct
{
  const char *pattern;    /* '^' for start of line match, everything
			     else verbatim */
  const char *replacement; /* Delete line, if NULL */
} sed_t;

/* A list of sed commands */
typedef struct
{
  sed_t *commands;
  size_t num;
  size_t alloc;
} sed_commands_t;

static void fatal (const char *, ...);
static void fatal_perror (const char *, ...);
static void append_option (options_t *, const char *);
static void append_options (options_t *, const options_t *);
static void append_sed (sed_commands_t *, const char *, const char *);
static void parse_args (int, char **);
static int execute (const char *, const char *, const options_t *, ...);
static int do_final_link (void);

static const char *myname;
static int flag_verbose = 0;
static int flag_final = 1;
static int have_elf2flt_options = 0;
static int flag_move_data = 0;
static int flag_help = 0;
static int flag_version = 0;
static const char *shared_lib_id = NULL;
static const char *output_file = "a.out";
static const char *linker_script = NULL;
static const char *emulation = NULL;
static const char *tmp_file = NULL;
static const char *output_gdb = NULL;
static const char *output_elf = NULL;
static const char *output_flt = NULL;
static options_t search_dirs;
static options_t all_options;
static options_t other_options;
static options_t flt_options;

static const char *linker = NULL;
static const char *elf2flt = NULL;
static const char *nm = NULL;
static const char *objdump = NULL;
static const char *objcopy = NULL;
static const char *ldscriptpath = BINUTILS_LDSCRIPTDIR;

static const char *response_file = NULL;

/* Initialize an options structure */
#define init_options(DST) \
	((DST)->options = NULL, (DST)->num = (DST)->alloc = 0)

/* Append a string SRC to an options array DST */

static void
append_option (options_t *dst, const char *src)
{
  if (dst->alloc == dst->num)
    {
      size_t a = (dst->num + 2) * 2;
      void *o = xmalloc (sizeof (*dst->options) * a);

      memcpy (o, dst->options, sizeof (*dst->options) * dst->num);
      free (dst->options);
      dst->options = o;
      dst->alloc = a;
    }

  dst->options[dst->num] = src;
  if (src)
    dst->num++;
}

/* Append an options array SRC to another options array DST */

static void
append_options (options_t *dst, const options_t *src)
{
  int ix;
  
  if (dst->alloc < dst->num + src->num)
    {
      size_t a = (dst->num + src->num + 2) * 2;
      void *o = xmalloc (sizeof (*dst->options) * a);

      memcpy (o, dst->options, sizeof (*dst->options) * dst->num);
      free (dst->options);
      dst->options = o;
      dst->alloc = a;
    }

  memcpy (&dst->options[dst->num], &src->options[0],
	  sizeof (*dst->options) * src->num);
  dst->num += src->num;
}

/* Initialize an options structure */
#define init_sed(DST) \
	((DST)->commands = NULL, (DST)->num = (DST)->alloc = 0)

/* Append a slot for a new sed command.  */

static void
append_sed (sed_commands_t *dst,
	    const char *pattern, const char *replacement)
{
  if (dst->alloc == dst->num)
    {
      size_t a = (dst->num + 2) * 2;
      void *o = xmalloc (sizeof (*dst->commands) * a);

      memcpy (o, dst->commands, sizeof (*dst->commands) * dst->num);
      free (dst->commands);
      dst->commands = o;
      dst->alloc = a;
    }

  dst->commands[dst->num].pattern = pattern;
  dst->commands[dst->num].replacement = replacement;
  
  dst->num++;
}

/* fatal error & exit */

static void
fatal (const char *format, ...)
{
  va_list args;

  va_start (args, format);
  fprintf (stderr, "%s:", myname);
  vfprintf (stderr, format, args);
  fprintf (stderr, "\n");
  va_end (args);
  exit (1);
}

/* fatal error, perror & exit */

static void
fatal_perror (const char *format, ...)
{
  int e = errno;
  va_list args;

  va_start (args, format);
  fprintf (stderr, "%s:", myname);
  vfprintf (stderr, format, args);
  fprintf (stderr, ": %s\n", xstrerror (e));
  va_end (args);
  exit (1);
}

static void
usage (void)
{
  FILE *stream = stdout;
  
  fprintf (stream, "elf2flt%s\n", PKGVERSION);
  fprintf (stream, "Usage: ld [opts] [linker-opts]\n");
  fprintf (stream, "  -elf2flt          : Perform FLT link\n");
  fprintf (stream, "  -elf2flt=opt      : Additional FLT option\n");
  fprintf (stream, "  -move-rodata      : Place rodata in text segment\n");
  fprintf (stream, "  -shared-lib-id N  : Specify shared library id\n");
  
  if (REPORT_BUGS_TO[0])
    printf ("Report bugs to %s\n", REPORT_BUGS_TO);
}

static void
show_version (void)
{
  printf ("elf2flt%s\n", PKGVERSION);
}

/* parse all the arguments provided to us */

static void
parse_args (int argc, char **argv)
{
  int argno;

  for (argno = 1; argno < argc; argno++)
    {
      char const *arg = argv[argno];
      int to_all = argno;

      /* We need to pass help and version through to the linker, so it
	 can generate output too.   */
      if (!strcmp (arg, "-h") || !strcmp (arg, "--help"))
	{
	  flag_help = 1;
	  append_option (&other_options, arg);
	}
      else if (!strcmp (arg, "--version"))
	{
	  flag_version = 1;
	  append_option (&other_options, arg);
	}
      if (!strcmp (arg, "-elf2flt"))
	{
	  have_elf2flt_options = 1;
	  to_all++;
	}
      else if (!strncmp (arg, "-elf2flt=", 9))
	{
	  have_elf2flt_options = 1;
	  append_option (&flt_options, &arg[9]);
	  to_all++;
	}
      else if (!strcmp (arg, "-move-rodata"))
	flag_move_data = 1;
      else if (!strcmp (arg, "-shared-lib-id"))
	shared_lib_id = argv[++argno];
      else if (!strncmp (arg, "-o", 2))
	output_file = arg[2] ? &arg[2] : argv[++argno];
      else if (!strncmp (arg, "-T", 2))
	linker_script = arg[2] ? &arg[2] : argv[++argno];
      else if (!strcmp (arg, "-c"))
	linker_script = argv[++argno];
      else if (!strncmp (arg, "-L", 2))
	{
	  const char *merged = (arg[2] ? arg
				: concat ("-L", argv[++argno], NULL));
	  
	  append_option (&other_options, merged);
	  append_option (&search_dirs, merged);
	}
      else if (!strcmp (arg, "-EB"))
	{
	  append_option (&other_options, arg);
	  append_option (&search_dirs, arg);
	}
      else if (!strcmp (arg, "-relax"))
	;
      else if (!strcmp (arg, "-s") || !strcmp (arg, "--strip-all")
	       || !strcmp (arg, "-S") || !strcmp (arg, "--strip-debug"))
	/* Ignore these strip options for links involving elf2flt.
	   The final flat output will be stripped by definition, and we
	   don't want to strip the .gdb helper file.  The strip options
	   are also incompatible with -r and --emit-relocs.  */
	;
      else if (!strcmp (arg, "-r") || !strcmp (arg, "-Ur"))
	{
	  flag_final = 0;
	  append_option (&other_options, arg);
	}
      else if (!strcmp (arg, "-v"))
	{
	  flag_verbose = 1;
	  append_option (&other_options, arg);
	}
      else if (!strncmp (arg, "-m", 2))
	emulation = arg[2] ? arg : concat ("-m", argv[++argno], NULL);
      else
	append_option (&other_options, arg);
      while (to_all <= argno)
	append_option (&all_options, argv[to_all++]);
    }
}

/* Rewrite OPTIONS to refer to a response file rather than an ordinary list of
   command-line options.  Set global response_file variable to the name of the
   temporary file created.  */
static void
use_response_file_for (options_t *options)
{
  FILE *f;
  int status;

  /* We're going to re-use the first option, so make sure it has space
     allocated for it.  There's no point in using a response file if it's going
     to be empty anyway.  */
  if (options->options == NULL || options->num < 1)
    return;

  response_file = make_temp_file ("");

  f = fopen (response_file, "w");
  
  if (f == NULL)
    fatal ("could not open response file %s", response_file);

  /* Make sure options list is NULL-terminated.  */
  if (options->options[options->num - 1] != 0)
    append_option (options, NULL);
  
  status = writeargv ((char **) options->options, f);
  
  if (status)
    fatal ("could not write to response file %s", response_file);

  status = fclose (f);
  
  if (EOF == status)
    fatal ("could not close response file %s", response_file);
  
  options->num = 1;
  options->options[0] = concat ("@", response_file, NULL);
}

/* Execute an external program COMMAND.  Write its stdout to OUTPUT,
   unless that is NULL.  Pass the trailing NULL terminated list of
   options, followed by all those in OPTIONS, if that is non-NULL.  */ 
static int
execute (const char *command, const char *output,
	 const options_t *options, ...)
{
  struct pex_obj *pex;
  const char *errmsg;
  int err;
  int status;
  va_list args;
  const char *opt;
  options_t opts;

  init_options (&opts);
  append_option (&opts, command);
  va_start (args, options);
  while ((opt = va_arg (args, const char *)))
    append_option (&opts, opt);
  va_end (args);
  if (options)
    append_options (&opts, options);
  append_option (&opts, NULL);
  
  fflush (stdout);
  fflush (stderr);

  pex = pex_init (0, myname, NULL);
  if (pex == NULL)
    fatal_perror ("pex_init failed");

  if (flag_verbose)
    {
      unsigned ix;

      fprintf (stderr, "Invoking:");
      for (ix = 0; ix != opts.num; ix++)
	fprintf (stderr, " %s", opts.options[ix]);
      fprintf (stderr, "\n");
    }
  
  errmsg = pex_run (pex, PEX_LAST | PEX_SEARCH, command,
		    (char *const *)opts.options, output, NULL, &err);
  if (errmsg != NULL)
    {
      if (err != 0)
	{
	  errno = err;
	  fatal_perror (errmsg);
	}
      else
	fatal (errmsg);
    }
  
  if (!pex_get_status (pex, 1, &status))
    fatal_perror ("can't get program status");
  pex_free (pex);

  if (status)
    {
      if (WIFSIGNALED (status))
	{
	  int sig = WTERMSIG (status);
	  
	  fatal ("%s terminated with signal %d [%s]%s",
		 command, sig, strsignal(sig),
		 WCOREDUMP(status) ? ", core dumped" : "");
	}

      if (WIFEXITED (status))
	return WEXITSTATUS (status);
    }
  return 0;
}

/* Read a line from IN.  LINE points to a malloc'd buffer that is extended as
   necessary.  ALLOC points to the allocated length of LINE.  Returns
   the length of the string read (including any trailing \n) */

static size_t 
read_line (FILE *in, char **line, size_t *alloc)
{
  size_t len = 0;

  if (!*alloc)
    {
      *alloc = 200;
      *line = xmalloc (*alloc);
    }
  
  while (1)
    {
      if (!fgets (*line + len, *alloc - len, in))
	return 0;
      len += strlen (*line + len);
      if (len && (*line)[len - 1] == '\n')
	return len;

      *alloc *= 2;
      *line = xrealloc (*line, *alloc);
    }
}

/* Apply the sed commands in SED to file NAME_IN producing file NAME_OUT */

static void
do_sed (const sed_commands_t *sed, const char *name_in, const char *name_out)
{
  FILE *in, *out;
  size_t alloc = 0;
  char *line = NULL;
  size_t len;
  
  in = fopen (name_in, "r");
  if (!in)
    fatal_perror ("cannot read linker script `%s'", name_in);
  out = fopen (name_out, "w");
  if (!out)
    fatal_perror ("cannot write temporary script `%s'", name_out);

  while ((len = read_line (in, &line, &alloc)))
    {
      int ix;

      for (ix = 0; ix != sed->num; ix++)
	{
	  const sed_t *command = &sed->commands[ix];
	  const char *pattern = command->pattern;
	  const char *ptr = line;
	  int bol = pattern[0] == '^';
	  size_t pat_len;
	  
	  pattern += bol;
	  pat_len = strlen (pattern);

	  if (!bol)
	    {
	      do
		{
		  ptr = strchr (ptr, pattern[0]);
		  if (!ptr)
		    ;
		  else if (!strncmp (ptr, pattern, pat_len))
		    goto found;
		  else
		    ptr++;
		}
	      while (ptr);
	    }
	  else if (!strncmp (ptr, pattern, pat_len))
	    {
	    found:
	      if (command->replacement)
		{
		  fwrite (line, 1, ptr - line, out);
		  fwrite (command->replacement, 1,
			  strlen (command->replacement), out);
		  fwrite (ptr + pat_len, 1,
			  len - pat_len - (ptr - line), out);
		}
	      goto next_line;
	    }
	}
      fwrite (line, 1, len, out);
    next_line:;
    }
  fclose (in);
  if (fclose (out))
    fatal_perror ("error writing temporary script '%s'", name_out);
  free (line);
}

/* If *NAME_PTR is null, set it to the name of a temporary file.  */

static void
create_tmp_file (const char **name_ptr)
{
  int fd;

  if (*name_ptr == NULL)
    {
      *name_ptr = concat (output_file, "-XXXXXX", NULL);
      fd = mkstemps (*name_ptr, 0);
      if (fd >= 0)
	close (fd);
      else
	fatal_perror ("cannot create temporary file");
    }
}

/* If *NAME_PTR is nonnull, delete the file it names and then set
   *NAME_PTR to null.  */

static void
delete_tmp_file (const char **name_ptr)
{
  if (*name_ptr != NULL)
    {
      unlink (*name_ptr);
      *name_ptr = NULL;
    }
}

/* Generate the flt binary along with any other necessary pieces.  */

static int
do_final_link ()
{
  sed_commands_t sed;
  sed_t *s;
  struct stat buf;
  const char *script;
  const char *rel_output;
  int status;
  int have_got = 0;
  FILE *in;
  char *line = NULL;
  size_t alloc = 0;
  size_t len;
  
  init_sed (&sed);

  if (flag_move_data)
    {
      FILE *in;

      /* See if the .rodata section contains any relocations.  */
      create_tmp_file (&output_flt);
      status = execute (linker, NULL, &other_options, "-r", "-d",
			"-o", output_flt, NULL);
      if (status)
	return status;
      status = execute (objdump, tmp_file, NULL, "-h", output_flt, NULL);
      if (status)
	return status;
      
      in = fopen (tmp_file, "r");
      if (!in)
	fatal_perror ("cannot read objdump output");
      while ((len = read_line (in, &line, &alloc)))
	{
	  const char *ptr = line;
	  
	  while (1)
	    {
	      ptr = strchr (ptr, '.');
	      if (!ptr)
		break;
	      if (!strncmp (ptr, ".rodata", 7))
		{
		  read_line (in, &line, &alloc);
		  ptr = line;
		  while (1)
		    {
		      ptr = strchr (ptr, 'R');
		      if (!ptr)
			break;
		      if (!strncmp (ptr, "RELOC", 5))
			{
			  flag_move_data = 0;
			  fprintf (stderr,
				   "warning: .rodata section contains relocations");
			  break;
			}
		      else
			ptr++;
		    }
		  break;
		}
	      else
		ptr++;
	    }
	}
      fclose (in);
    }
  append_sed (&sed, "^R_RODAT", flag_move_data ? NULL : "");
  append_sed (&sed, "^W_RODAT", flag_move_data ? "" : NULL);
  /* We don't need a relocatable link if USE_EMIT_RELOCS.  */
  append_sed (&sed, "^EXEC:", USE_EMIT_RELOCS ? "" : NULL);

  if (shared_lib_id)
    {
      const char *got_offset;
      int id = strtol (shared_lib_id, NULL, 0);
      char buf[30];

      /* Replace addresses using the shared object id.   */
      sprintf (buf, "%.2X", id);
      append_sed (&sed, "ORIGIN = 0x0,",
		  concat ("ORIGIN = 0x", buf, "000000,", NULL));
      append_sed (&sed, ".text 0x0 :",
		  concat (".text 0x0", buf, "000000 :", NULL));
      if (id)
	append_sed (&sed, "ENTRY (_start)", "ENTRY (lib_main)");

      /* Provide the symbol specifying the library's data segment
	 pointer offset.  */
      if (!strcmp (TARGET_CPU, "h8300"))
	got_offset="__current_shared_library_er5_offset_";
      else
	got_offset="_current_shared_library_a5_offset_";
      append_option (&other_options, "-defsym");
      sprintf (buf, "%d", id * -4 - 4);
      append_option (&other_options, concat (got_offset, "=", buf, NULL));
    }

  /* Locate the default linker script, if we don't have one provided.
   */
  if (!linker_script)
    linker_script = concat (ldscriptpath, "/elf2flt.ld", NULL);

  /* Try and locate the linker script.  */
  script = linker_script;
  if (stat (script, &buf) || !S_ISREG (buf.st_mode))
    {
      script = concat (ldscriptpath, "/", linker_script, NULL);
      if (stat (script, &buf) || !S_ISREG (buf.st_mode))
	{
	  script = concat (ldscriptpath, "/ldscripts/", linker_script, NULL);
	  if (stat (script, &buf) || !S_ISREG (buf.st_mode))
	    script = NULL;
	}
    }
  /* And process it if we can -- if we can't find it, the user must
     know what they are doing.  */
  if (script)
    {
      do_sed (&sed, linker_script, tmp_file);
      linker_script = tmp_file;
    }

  if (USE_EMIT_RELOCS)
    {
      status = execute (linker, NULL, &other_options, "-T", linker_script,
			"-q", "-o", output_gdb, emulation, NULL);
      if (status)
	return status;

      append_option (&flt_options, "-a");
      rel_output = output_gdb;
    }
  else if (NO_GOT_CHECK)
    {
      create_tmp_file (&output_elf);
      status = execute (linker, NULL, &other_options, "-T", linker_script,
			"-Ur", "-d", "-o", output_elf, emulation, NULL);
      if (status)
	return status;
      
      status = execute (linker, NULL, &other_options, "-T", linker_script,
			"-o", output_gdb, emulation, NULL);
      if (status)
	return status; 

      rel_output = output_elf;
    }
  else
    {
      create_tmp_file (&output_flt);
      status = execute (linker, NULL, &other_options, "-r", "-d",
			"-o", output_flt, emulation, NULL);
      if (status)
	return status;
      
      create_tmp_file (&output_elf);
      status = execute (linker, NULL, &search_dirs, "-T", linker_script, "-Ur",
			"-o", output_elf, output_flt, emulation, NULL);
      if (status)
	return status;
      
      status = execute (linker, NULL, &search_dirs, "-T", linker_script,
			"-o", output_gdb, output_flt, emulation, NULL);
      if (status)
	return status;
      
      rel_output = output_elf;
    }

  if (shared_lib_id && strtol (shared_lib_id, NULL, 0) != 0)
    {
      status = execute (objcopy, NULL, NULL, "--localize-hidden",
			"--weaken", output_gdb, NULL);
      if (status)
	return status;
    }

  status = execute (nm, tmp_file, NULL, "-p", output_gdb, NULL);
  if (status)
    return status;
  in = fopen (tmp_file, "r");
  if (!in)
    fatal_perror ("cannot read nm output");
  while ((len = read_line (in, &line, &alloc)))
    {
      const char *ptr = strchr (line, '_');
      if (ptr && !strncmp (ptr, "_GLOBAL_OFFSET_TABLE",
			   strlen ("_GLOBAL_OFFSET_TABLE")))
	{
	  have_got = 1;
	  break;
	}
    }
  fclose (in);
  if (have_got)
    status = execute (elf2flt, NULL, &flt_options, "-o", output_file,
		      "-p", output_gdb, rel_output, NULL);
  else
    status = execute (elf2flt, NULL, &flt_options, "-o", output_file,
		      "-r", rel_output, NULL);
  if (status)
    return status;

  return 0;    
}

int
main (int argc, char **argv)
{
  const char *ptr;
  char *tmp;
  const char *full_argv0 = argv[0]; /* argv0 with required suffix.  */
  size_t len;
  struct stat buf;
  int status;
  char *exec_prefix;
  const char *tooldir;
  char **old_argv = argv;
  int response_file_supplied = 0;

  expandargv (&argc, &argv);

  if (argv != old_argv)
    response_file_supplied = 1;

  myname = argv[0];
  for (ptr = myname + strlen (myname); ptr != myname; ptr--)
    if (IS_DIR_SEPARATOR (ptr[-1]))
      {
	myname = ptr;
	break;
      }
  xmalloc_set_program_name (myname);
#ifdef __WIN322
  len = strlen (myname);
  /* Remove a .exe suffix, if there is one.  */
  if (len > 4 && strcmp (&myname[len - 4], ".exe"))
    {
      tmp = xmalloc (len);
      memcpy (tmp, myname, len);
      tmp[len-4] = 0;
      myname = tmp;
      xmalloc_set_program_name (myname);
    }
#endif

  /* Find the bin dir.  */
  tooldir = make_relative_prefix (full_argv0, "/", "/");
  if (!tooldir)
    tooldir = "";

  /* We have to determine whether we found the internal bin directory
     (<prefix>/TARGET_ALIAS/bin) or the external bin directory
     (<prefix>/bin).  Executables in the latter will have a
     TARGET_ALIAS prefix and executables in the former will have no
     prefix.  We extract TARGET_ALIAS from the command, rather than
     use a constant.  It sure would be nice if we didn't have the
     internal bin directory!  */
  for (len = strlen (myname); len && myname[len-1] != '-'; len--)
    continue;
  if (len)
    {
      tmp = xstrdup (myname);
      tmp[len] = 0;
      exec_prefix = tmp;
    }
  else
    exec_prefix = "";
  
  linker = concat (tooldir, exec_prefix, "ld.real", NULL);
  elf2flt = concat (tooldir, exec_prefix, "elf2flt", NULL);
  nm = concat (tooldir, exec_prefix, "nm", NULL);
  objdump = concat (tooldir, exec_prefix, "objdump", NULL);
  objcopy = concat (tooldir, exec_prefix, "objcopy", NULL);

  if (tooldir[0] && stat (ldscriptpath, &buf) || !S_ISDIR (buf.st_mode))
    {
      /* The script directory is <prefix>/TARGET_ALIAS/lib.  So, if we
	 have an exec-prefix, all we need to do is convert the
	 trailing - to a /.  */
      if (len)
	exec_prefix[len-1] = '/';
      
      ldscriptpath = concat (tooldir, "../", exec_prefix, "lib", NULL);
    }
  
  parse_args (argc, argv);

  if (flag_verbose)
    {
      fprintf (stderr, "argv[0]      = '%s'\n", argv[0]);
      fprintf (stderr, "tooldir      = '%s'\n", tooldir);
      fprintf (stderr, "linker       = '%s'\n", linker);
      fprintf (stderr, "elf2flt	     = '%s'\n", elf2flt);
      fprintf (stderr, "nm           = '%s'\n", nm);
      fprintf (stderr, "objdump	     = '%s'\n", objdump);
      fprintf (stderr, "objcopy	     = '%s'\n", objcopy);
      fprintf (stderr, "ldscriptpath = '%s'\n", ldscriptpath);
    }

  /* Pass off to regular linker, if there's nothing elf2flt-like */
  if (!have_elf2flt_options)
    {
      /* If we were passed arguments which included a response file, pass
	 all_options using a response file too.  Note that we only use a
	 single response file for either all_options (here) or
	 other_options (below), but never both simultaneously.  */
      if (response_file_supplied)
	use_response_file_for (&all_options);
    
      status = execute (linker, NULL, &all_options, NULL);
      if (flag_help)
	usage ();
      if (flag_version)
	show_version ();
      delete_tmp_file (&response_file);
      return status;
    }

  /* If we were passed arguments which included a response file, pass
     other_options using a response file too.  (See note in "Pass off to
     regular linker [...]" above also).  */
  if (response_file_supplied)
    use_response_file_for (&other_options);

  /* Pass off to regular linker, minus the elf2flt options, if it's
     not the final link.  */
  if (!flag_final)
    {
      int ret = execute (linker, NULL, &other_options, "-o", output_file, NULL);
      delete_tmp_file (&response_file);
      return ret;
    }

  /* Otherwise link & convert to flt.  */
  output_gdb = concat (output_file, ".gdb", NULL);
  create_tmp_file (&tmp_file);
  status = do_final_link ();
  delete_tmp_file (&tmp_file);
  delete_tmp_file (&output_flt);
  delete_tmp_file (&output_elf);
  delete_tmp_file (&response_file);
  return status;
}
