#source: fdpic-goti20-shared.s
#as: --isa=sh2a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.text:
 01dc 0000000c 01ce[ \t]+.*
Contents of section \.got:
 10254 00000000 00000000 00000000 00000000[ \t]+.*

Disassembly of section \.text:

000001dc <f>:
 1dc:[ \t]+00 00 00 0c[ \t]+movi20[ \t]+#12,r0
 1e0:[ \t]+01 ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r1

Disassembly of section \.got:

00010254 <\.got>:
[ \t]+\.\.\.
[ \t]+10260: R_SH_GLOB_DAT[ \t]+foo
