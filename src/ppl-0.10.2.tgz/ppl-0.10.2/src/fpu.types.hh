/* Copyright (C) 2001-2009 Roberto Bagnara <bagnara@cs.unipr.it>

This file is free software; as a special exception the author gives
unlimited permission to copy and/or distribute it, with or without
modifications, as long as this notice is preserved.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY, to the extent permitted by law; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. */

#ifndef PPL_fpu_types_hh
#define PPL_fpu_types_hh 1

#ifdef PPL_HAVE_IEEEFP_H
#include <ieeefp.h>
#endif

namespace Parma_Polyhedra_Library {

enum fpu_rounding_direction_type {};
enum fpu_rounding_control_word_type {};

} // namespace Parma_Polyhedra_Library

#endif // !defined(PPL_fpu_types_hh)
