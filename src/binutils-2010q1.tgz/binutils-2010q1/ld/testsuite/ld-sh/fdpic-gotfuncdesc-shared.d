#source: fdpic-gotfuncdesc-shared.s
#as: --isa=sh2a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.text:
 01dc d00001ce 0000000c[ \t]+.*
Contents of section \.got:
 10254 00000000 00000000 00000000 00000000[ \t]+.*

Disassembly of section \.text:

000001dc <f>:
 1dc:[ \t]+d0 00[ \t]+mov\.l[ \t]+1e0 <f\+0x4>,r0[ \t]+! c
 1de:[ \t]+01 ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 1e0:[ \t]+00 00 00 0c[ \t]+movi20[ \t]+#12,r0

Disassembly of section \.got:

00010254 <\.got>:
[ \t]+\.\.\.
[ \t]+10260: R_SH_FUNCDESC[ \t]+foo
