#source: fdpic-gotofffuncdesc-shared.s
#as: --isa=sh2a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.text:
 01c4 d10031cc fffffff8 00090009[ \t]+.*
Contents of section \.got:
 10240 00000008 00000000 00000000 00000000[ \t]+.*
 10250 00000000[ \t]+.*

Disassembly of section \.text:

000001c4 <f>:
 1c4:[ \t]+d1 00[ \t]+mov\.l[ \t]+1c8 <f\+0x4>,r1[ \t]+! fffffff8
 1c6:[ \t]+31 cc[ \t]+add[ \t]+r12,r1
 1c8:[ \t]+ff ff[ \t]+\.word 0xffff
 1ca:[ \t]+ff f8[ \t]+fmov[ \t]+@r15,fr15

000001cc <foo>:
 1cc:[ \t]+00 09[ \t]+nop[ \t]+
 1ce:[ \t]+00 09[ \t]+nop[ \t]+

Disassembly of section \.got:

00010240 <\.got>:
[ \t]+10240:[ \t]+00 00 00 08[ \t]+movi20[ \t]+#8,r0
[ \t]+10240: R_SH_FUNCDESC_VALUE[ \t]+\.text
[ \t]+\.\.\.
