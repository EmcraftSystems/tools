
Relocation section '\.rel\.dyn' at offset .* contains .*:
 * Offset * Info * Type * Sym\.Value * Sym\. Name
00000000 * 00000000 * R_MIPS_NONE *
000a2000 * 0000017e * R_MIPS_COPY * 000a2000 * obj1
000a2008 * 0000047e * R_MIPS_COPY * 000a2008 * obj2
000a1004 * 00000703 * R_MIPS_REL32 * 00000000 * obj3
