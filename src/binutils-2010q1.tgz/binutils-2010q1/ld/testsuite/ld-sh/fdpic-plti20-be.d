#source: fdpic-plt.s
#as: --isa=sh2a -big --fdpic
#ld: -EB -mshelf_fd -shared
#objdump: -dsR -j.plt -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-shbig-fdpic

Contents of section \.plt:
 0214 00f0fff0 01ce7004 412b0cce 00000000[ \t]+.*
 0224 60c2402b 53c10009 00f0fff8 01ce7004[ \t]+.*
 0234 412b0cce 0000000c 60c2402b 53c10009[ \t]+.*
Contents of section \.text:
 0244 d000d101 ffffffcc ffffffe0[ \t]+.*
Contents of section \.got:
 102c8 00000224 00000000 0000023c 00000000[ \t]+.*
 102d8 00000000 00000000 00000000[ \t]+.*

Disassembly of section \.plt:

00000214 <foo@plt>:
 214:[ \t]+00 f0 ff f0[ \t]+movi20[ \t]+#-16,r0
 218:[ \t]+01 ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 21a:[ \t]+70 04[ \t]+add[ \t]+#4,r0
 21c:[ \t]+41 2b[ \t]+jmp[ \t]+@r1
 21e:[ \t]+0c ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 220:[ \t]+00 00 00 00[ \t]+movi20[ \t]+#0,r0
 224:[ \t]+60 c2[ \t]+mov\.l[ \t]+@r12,r0
 226:[ \t]+40 2b[ \t]+jmp[ \t]+@r0
 228:[ \t]+53 c1[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 22a:[ \t]+00 09[ \t]+nop[ \t]+

0000022c <bar@plt>:
 22c:[ \t]+00 f0 ff f8[ \t]+movi20[ \t]+#-8,r0
 230:[ \t]+01 ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 232:[ \t]+70 04[ \t]+add[ \t]+#4,r0
 234:[ \t]+41 2b[ \t]+jmp[ \t]+@r1
 236:[ \t]+0c ce[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 238:[ \t]+00 00 00 0c[ \t]+movi20[ \t]+#12,r0
 23c:[ \t]+60 c2[ \t]+mov\.l[ \t]+@r12,r0
 23e:[ \t]+40 2b[ \t]+jmp[ \t]+@r0
 240:[ \t]+53 c1[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 242:[ \t]+00 09[ \t]+nop[ \t]+

Disassembly of section \.text:

00000244 <f>:
 244:[ \t]+d0 00[ \t]+mov\.l[ \t]+248 <f\+0x4>,r0[ \t]+! ffffffcc
 246:[ \t]+d1 01[ \t]+mov\.l[ \t]+24c <f\+0x8>,r1[ \t]+! ffffffe0
 248:[ \t]+ff ff[ \t]+\.word 0xffff
 24a:[ \t]+ff cc[ \t]+fmov[ \t]+fr12,fr15
 24c:[ \t]+ff ff[ \t]+\.word 0xffff
 24e:[ \t]+ff e0[ \t]+fadd[ \t]+fr14,fr15

Disassembly of section \.got:

000102c8 <\.got>:
[ \t]+102c8:[ \t]+00 00 02 24[ \t]+movi20[ \t]+#548,r0
[ \t]+102c8: R_SH_FUNCDESC_VALUE[ \t]+foo
[ \t]+102cc:[ \t]+00 00 00 00[ \t]+movi20[ \t]+#0,r0
[ \t]+102d0:[ \t]+00 00 02 3c[ \t]+movi20[ \t]+#572,r0
[ \t]+102d0: R_SH_FUNCDESC_VALUE[ \t]+bar
[ \t]+\.\.\.
