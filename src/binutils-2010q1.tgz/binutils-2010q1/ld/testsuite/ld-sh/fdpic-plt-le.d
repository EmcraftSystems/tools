#source: fdpic-plt.s
#as: --isa=sh4a -little --fdpic
#ld: -EL -mshlelf_fd -shared
#objdump: -dsR -j.plt -j.text -j.got
#target: sh*-*-uclinux*

.*:[ \t]+file format elf32-sh-fdpic

Contents of section \.plt:
 0214 02d0ce01 04702b41 ce0c0900 f0ffffff[ \t]+.*
 0224 00000000 c2602b40 c1530900 02d0ce01[ \t]+.*
 0234 04702b41 ce0c0900 f8ffffff 0c000000[ \t]+.*
 0244 c2602b40 c1530900[ \t]+.*
Contents of section \.text:
 024c 00d001d1 c4ffffff dcffffff[ \t]+.*
Contents of section \.got:
 102d0 28020000 00000000 44020000 00000000[ \t]+.*
 102e0 00000000 00000000 00000000[ \t]+.*

Disassembly of section \.plt:

00000214 <foo@plt>:
 214:[ \t]+02 d0[ \t]+mov\.l[ \t]+220 <foo@plt\+0xc>,r0[ \t]+! fffffff0
 216:[ \t]+ce 01[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 218:[ \t]+04 70[ \t]+add[ \t]+#4,r0
 21a:[ \t]+2b 41[ \t]+jmp[ \t]+@r1
 21c:[ \t]+ce 0c[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 21e:[ \t]+09 00[ \t]+nop[ \t]+
 220:[ \t]+f0 ff[ \t]+fadd[ \t]+fr15,fr15
 222:[ \t]+ff ff[ \t]+\.word 0xffff
 224:[ \t]+00 00[ \t]+\.word 0x0000
 226:[ \t]+00 00[ \t]+\.word 0x0000
 228:[ \t]+c2 60[ \t]+mov\.l[ \t]+@r12,r0
 22a:[ \t]+2b 40[ \t]+jmp[ \t]+@r0
 22c:[ \t]+c1 53[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 22e:[ \t]+09 00[ \t]+nop[ \t]+

00000230 <bar@plt>:
 230:[ \t]+02 d0[ \t]+mov\.l[ \t]+23c <bar@plt\+0xc>,r0[ \t]+! fffffff8
 232:[ \t]+ce 01[ \t]+mov\.l[ \t]+@\(r0,r12\),r1
 234:[ \t]+04 70[ \t]+add[ \t]+#4,r0
 236:[ \t]+2b 41[ \t]+jmp[ \t]+@r1
 238:[ \t]+ce 0c[ \t]+mov\.l[ \t]+@\(r0,r12\),r12
 23a:[ \t]+09 00[ \t]+nop[ \t]+
 23c:[ \t]+f8 ff[ \t]+fmov[ \t]+@r15,fr15
 23e:[ \t]+ff ff[ \t]+\.word 0xffff
 240:[ \t]+0c 00[ \t]+mov\.b[ \t]+@\(r0,r0\),r0
 242:[ \t]+00 00[ \t]+\.word 0x0000
 244:[ \t]+c2 60[ \t]+mov\.l[ \t]+@r12,r0
 246:[ \t]+2b 40[ \t]+jmp[ \t]+@r0
 248:[ \t]+c1 53[ \t]+mov\.l[ \t]+@\(4,r12\),r3
 24a:[ \t]+09 00[ \t]+nop[ \t]+

Disassembly of section \.text:

0000024c <f>:
 24c:[ \t]+00 d0[ \t]+mov\.l[ \t]+250 <f\+0x4>,r0[ \t]+! ffffffc4
 24e:[ \t]+01 d1[ \t]+mov\.l[ \t]+254 <f\+0x8>,r1[ \t]+! ffffffdc
 250:[ \t]+c4 ff[ \t]+fcmp/eq[ \t]+fr12,fr15
 252:[ \t]+ff ff[ \t]+\.word 0xffff
 254:[ \t]+dc ff[ \t]+fmov[ \t]+fr13,fr15
 256:[ \t]+ff ff[ \t]+\.word 0xffff

Disassembly of section \.got:

000102d0 <\.got>:
[ \t]+102d0:[ \t]+28 02[ \t]+\.word 0x0228
[ \t]+102d0: R_SH_FUNCDESC_VALUE[ \t]+foo
[ \t]+102d2:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d4:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d6:[ \t]+00 00[ \t]+\.word 0x0000
[ \t]+102d8:[ \t]+44 02[ \t]+mov\.b[ \t]+r4,@\(r0,r2\)
[ \t]+102d8: R_SH_FUNCDESC_VALUE[ \t]+bar
[ \t]+\.\.\.
