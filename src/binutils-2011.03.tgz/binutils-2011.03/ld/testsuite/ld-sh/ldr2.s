 .text
 .long bar
bar:
