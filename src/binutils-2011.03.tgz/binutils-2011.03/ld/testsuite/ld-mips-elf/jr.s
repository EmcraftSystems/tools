	jr	$31
